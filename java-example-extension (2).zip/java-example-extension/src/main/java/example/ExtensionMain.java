package example;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

public class ExtensionMain {

    public static void main(String[] args) {
        // Register the extension for "INVOKE" and "SHUTDOWN" events
        final String extension = ExtensionClient.registerExtension();
        System.out.println("Extension registration complete, extensionID: " + extension);

        // Start the HTTP server to listen for logs
        ExtensionHttpListener httpListener = new ExtensionHttpListener();
        httpListener.listen("localhost", 8080);

        // Add a shutdown hook to gracefully stop the HTTP server when the application exits
        Runtime.getRuntime().addShutdownHook(new Thread(httpListener::stop));

        while (true) {
            try {
                String response = ExtensionClient.getNext(extension);
                if (response != null && !response.isEmpty()) {
                    JsonObject eventJsonObject = new Gson().fromJson(response, JsonObject.class);
                    JsonElement eventTypeElement = eventJsonObject.get("eventType");

                    // Depending upon event type, perform corresponding actions
                    if (eventTypeElement != null) {
                        final String eventType = eventTypeElement.getAsString();
                        switch (eventType) {
                            case "INVOKE":
                                handleInvoke(response, httpListener);
                                break;
                            case "SHUTDOWN":
                                handleShutDown(httpListener);
                                break;
                            default:
                                System.err.println("Invalid event type received: " + eventType);
                        }
                    }
                }
            } catch (Exception e) {
                System.err.println("Error while processing extension: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    /**
     * Shutdown extension if we receive a shutdown event from the Lambda container.
     */
    private static void handleShutDown(ExtensionHttpListener httpListener) {
        System.out.println("Shutting down the extension");
        httpListener.stop();
        System.exit(0);
    }

    /**
     * Process payload for INVOKE events.
     *
     * @param payload      The event payload.
     * @param httpListener The HTTP listener instance.
     */
    public static void handleInvoke(String payload, ExtensionHttpListener httpListener) {
        System.out.println("Handling invoke from extension: " + payload);

        // Example: Read logs from the HTTP listener's logsQueue
        if (!httpListener.getLogsQueue().isEmpty()) {
            System.out.println("Processing logs from the queue...");
            httpListener.getLogsQueue().forEach(log -> System.out.println("Log: " + log));
            httpListener.getLogsQueue().clear(); // Clear logs after processing
        } else {
            System.out.println("No logs available in the queue.");
        }
    }
}
