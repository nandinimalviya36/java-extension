package example;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
import org.json.JSONObject;

public class ExtensionLogsApi {

    private static final String BASE_URL = "http://" + System.getenv("AWS_LAMBDA_RUNTIME_API") + "/2020-08-15/logs";

    public static void subscribe(String extensionId, JSONObject subscriptionBody) {
        try {
            URL url = new URL(BASE_URL);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("PUT");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("Lambda-Extension-Identifier", extensionId);
            connection.setDoOutput(true);

            // Write the subscription body to the request
            try (OutputStream os = connection.getOutputStream()) {
                byte[] input = subscriptionBody.toString().getBytes(StandardCharsets.UTF_8);
                os.write(input, 0, input.length);
            }

            int statusCode = connection.getResponseCode();

            switch (statusCode) {
                case 200:
                    try (Scanner scanner = new Scanner(connection.getInputStream(), StandardCharsets.UTF_8)) {
                        System.out.println("Logs subscription successful: " + scanner.useDelimiter("\\A").next());
                    }
                    break;

                case 202:
                    System.out.println("WARNING!!! Logs API is not supported! Is this extension running in a local sandbox?");
                    break;

                default:
                    try (Scanner scanner = new Scanner(connection.getErrorStream(), StandardCharsets.UTF_8)) {
                        System.err.println("Logs subscription failed: " + scanner.useDelimiter("\\A").next());
                    }
                    break;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
