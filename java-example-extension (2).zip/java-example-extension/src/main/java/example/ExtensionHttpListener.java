package example;
import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import org.json.JSONArray;
import org.json.JSONException;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ExtensionHttpListener {

    private final List<Object> logsQueue = new ArrayList<>();
    private HttpServer server;

    /**
     * Start the HTTP server for listening to logs.
     *
     * @param address The address to bind the server to.
     * @param port    The port to bind the server to.
     */
    public void listen(String address, int port) {
        try {
            // Create an HTTP server bound to the given address and port
            server = HttpServer.create(new InetSocketAddress(address, port), 0);

            // Set the handler for incoming requests
            server.createContext("/", new HttpHandler() {
                @Override
                public void handle(HttpExchange exchange) {
                    try {
                        String method = exchange.getRequestMethod();

                        if ("POST".equalsIgnoreCase(method)) {
                            // Handle POST requests
                            handlePostRequest(exchange);
                        } else {
                            // Handle GET requests
                            handleGetRequest(exchange);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });

            // Start the server
            server.start();
            System.out.println("Listening for logs at http://" + address + ":" + port);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Handle POST requests by parsing incoming logs and adding them to the queue.
     *
     * @param exchange The HTTP exchange object for the request.
     */
    private void handlePostRequest(HttpExchange exchange) {
        try (InputStream inputStream = exchange.getRequestBody()) {
            // Use a try-with-resources block for Scanner
            try (Scanner scanner = new Scanner(inputStream, "UTF-8").useDelimiter("\\A")) {
                String body = scanner.hasNext() ? scanner.next() : "";

                System.out.println("Logs listener received: " + body);

                // Attempt to parse the incoming JSON batch
                try {
                    JSONArray batch = new JSONArray(body);
                    if (batch.length() > 0) {
                        for (int i = 0; i < batch.length(); i++) {
                            logsQueue.add(batch.get(i));
                        }
                    }
                } catch (JSONException e) {
                    System.out.println("Failed to parse logs: " + e.getMessage());
                }

                // Send a 200 OK response
                sendResponse(exchange, 200, "OK");
            }
        } catch (Exception e) {
            e.printStackTrace();
            sendResponse(exchange, 500, "Internal Server Error");
        }
    }

    /**
     * Handle GET requests by sending a simple 200 OK response.
     *
     * @param exchange The HTTP exchange object for the request.
     */
    private void handleGetRequest(HttpExchange exchange) {
        System.out.println("GET");
        sendResponse(exchange, 200, "OK");
    }

    /**
     * Send a response back to the client.
     *
     * @param exchange    The HTTP exchange object for the request.
     * @param statusCode  The HTTP status code to send.
     * @param responseBody The response body to send.
     */
    private void sendResponse(HttpExchange exchange, int statusCode, String responseBody) {
        try {
            exchange.sendResponseHeaders(statusCode, responseBody.getBytes().length);
            try (OutputStream outputStream = exchange.getResponseBody()) {
                outputStream.write(responseBody.getBytes());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Stop the HTTP server.
     */
    public void stop() {
        if (server != null) {
            server.stop(0);
            System.out.println("Server stopped.");
        }
    }

    /**
     * Get the logs queue.
     *
     * @return The list of logs received.
     */
    public List<Object> getLogsQueue() {
        return logsQueue;
    }
}
